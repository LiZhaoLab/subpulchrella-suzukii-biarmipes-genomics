#!/usr/bin/env python3
"""Script 140: neutral-site Ne and the manuscript numbers of Sato1106.docx paragraphs 35, 62, 96 and
97, recomputed with short introns of 40-65 bp (Airi Sato's final definition) instead of 30-65 bp.

Inputs (per-chunk block sums of scripts 32 and 33): QC/stats/div{SET}, QC/stats/dstd{SET}; SET = '' (30-65 bp,
original runs) or '_si40' (40-65 bp, rerun, scripts/run_si40_rerun.sh).
Estimates, as in scripts 40 and 43 (callable-weighted theta per site; Ne = theta / (4 mu), mu = 3.3e-9;
95% intervals from chromosome-stratified 1-Mb block bootstraps, seed 20261021; full depth 10,000 replicates,
depth-standardized 2,000 replicates). Block files are read in sorted order.
Numbers (autosomes), as defined by script 71:
  Ne_red      100 x (1 - Ne Dsub / Ne pool), range over the four D. suzukii pools, for each of full-depth thetaW,
              full-depth pi (P99_noRM, the configuration of paragraph 97) and depth-standardized thetaW and pi
              (T = 30), per site class; Ne_red_SI_all / Ne_red_FF_all = range over the four analyses (para. 35)
  overlap     whether any D. subpulchrella 95% interval overlaps a D. suzukii interval (para. 35, 62)
  lowest      whether D. subpulchrella has the lowest estimate in every analysis (para. 62)
  retained    depth-standardized valid sites / full-depth valid sites, all sites, P99_noRM (para. 96)
  vs_grenedalf  100 x (1 - my thetaW Ne / Airi's grenedalf thetaW Ne), short introns, autosomes (para. 97).
              Like-for-like: my P98_RM (98th percentile, RepeatMasker mask) 40-65-bp estimate against Airi's final
              run (Ne_reanalysis_20261023_repeatmasker_p98: P98, RepeatMasker, 40-65 bp). Also reported: my
              P99_noRM estimate against the same values.
Usage: 140_si40_numbers.py check   (SET = '': must reproduce results/L2_Ne.tsv, L2_depth_standardized_Ne.tsv and
                                    the numbers of additional_methods_numbers.json)
       140_si40_numbers.py run     (SET = '_si40'; writes results/Ne_si40.tsv,
                                    results/depth_standardized_Ne_si40.tsv, results/si40_numbers.json,
                                    results/si40_numbers.log)
"""
import glob
import json
import sys

import numpy as np
import pandas as pd

QC = '/ru-auth/local/home/lzhao/Data_scratch/zhao/suzukii_QC'
RES = '/ru-auth/local/home/lzhao/vscode_projects/suzukii/results'
AIRI = ('/ru-auth/local/home/asato/scratch/population_polymorphism/Ne_reanalysis_20261023_repeatmasker_p98/results/'
        'effective_population_size/effective_population_size_block_bootstrap.tsv')
MU, SEED = 3.3e-9, 20261021
SAMPLES = ['Dsub_L5_7', 'JP-Kan', 'JP-Sap', 'JP-Sap2', 'JP-Tok']
POPS = SAMPLES[1:]


def rng_txt(v, d):
    a, b = f'{min(v):.{d}f}', f'{max(v):.{d}f}'
    return a if a == b else f'{a}–{b}'


def ne_table(blocks, keys, nboot):
    rng = np.random.default_rng(SEED)
    rows = []
    for k, g in blocks.groupby(keys):
        g = g[g.n_valid > 0]
        nv, stw, spi = g.n_valid.values, g.sum_tw.values, g.sum_pi.values
        f = (3 if dict(zip(keys, k))['cls'] == 'X' else 4) * MU
        groups = [np.flatnonzero(g.chrom.values == c) for c in np.unique(g.chrom.values)]
        bt, bp = np.empty(nboot), np.empty(nboot)
        for r in range(nboot):
            pick = np.concatenate([rng.choice(ix, len(ix)) for ix in groups])
            bt[r] = stw[pick].sum() / nv[pick].sum()
            bp[r] = spi[pick].sum() / nv[pick].sum()
        rows.append(dict(zip(keys, k), blocks=len(g), valid_sites=int(nv.sum()), snps=int(g.S.sum()),
                         pi=spi.sum() / nv.sum(), tw=stw.sum() / nv.sum(),
                         Ne_tw=stw.sum() / nv.sum() / f, Ne_tw_lo=np.percentile(bt, 2.5) / f,
                         Ne_tw_hi=np.percentile(bt, 97.5) / f, Ne_pi=spi.sum() / nv.sum() / f,
                         Ne_pi_lo=np.percentile(bp, 2.5) / f, Ne_pi_hi=np.percentile(bp, 97.5) / f))
    return pd.DataFrame(rows)


def load(kind, s):
    files = sorted(glob.glob(f'{QC}/stats/{kind}{s}/*.blocks.tsv.gz'))
    assert len(files) == 102, (kind, s, len(files))
    return pd.concat(pd.read_csv(f, sep='\t') for f in files)


def numbers(full, dstd, say):
    J = {}
    a = full[full.cls == 'autosome']
    d = dstd[dstd.cls == 'autosome']
    analyses = [('full_tw', a[a.config == 'P99_noRM'], 'Ne_tw'), ('full_pi', a[a.config == 'P99_noRM'], 'Ne_pi'),
                ('d30_tw', d, 'Ne_tw'), ('d30_pi', d, 'Ne_pi')]
    red, overlap, lowest = {}, [], []
    for sc in ('short_intron', 'fourfold'):
        for lab, t, col in analyses:
            t = t[t.site_class == sc].set_index('sample')
            v = [100 * (1 - t[col]['Dsub_L5_7'] / t[col][p]) for p in POPS]
            red[f'{sc}_{lab}'] = rng_txt(v, 1)
            overlap += [bool(t[f'{col}_hi']['Dsub_L5_7'] >= t[f'{col}_lo'][p]) for p in POPS]
            lowest.append(bool(t[col].idxmin() == 'Dsub_L5_7'))
            say(f'  {sc:12s} {lab}: Dsub {t[col]["Dsub_L5_7"] / 1e6:.3f} x 10^6 '
                f'({t[f"{col}_lo"]["Dsub_L5_7"] / 1e6:.3f}-{t[f"{col}_hi"]["Dsub_L5_7"] / 1e6:.3f}); pools '
                + ', '.join(f'{p} {t[col][p] / 1e6:.3f} ({t[f"{col}_lo"][p] / 1e6:.3f}-{t[f"{col}_hi"][p] / 1e6:.3f})'
                            for p in POPS) + f'; Dsub lower by {red[f"{sc}_{lab}"]}%')
    J['Ne_red'] = red
    for sc, key in (('short_intron', 'Ne_red_SI_all'), ('fourfold', 'Ne_red_FF_all')):
        v = [float(x) for k, r in red.items() if k.startswith(sc) for x in r.split('–')]
        J[key] = f'{min(v):.0f}–{max(v):.0f}'
    J['Ne_ci_overlap_any'] = bool(any(overlap))
    J['Dsub_lowest_all'] = bool(all(lowest))
    # retained fraction after depth standardization (all sites, P99_noRM, per class)
    fa = full[(full.config == 'P99_noRM') & (full.site_class == 'all')].set_index(['cls', 'sample']).valid_sites
    da = dstd[dstd.site_class == 'all'].set_index(['cls', 'sample']).valid_sites
    ret = (da / fa).dropna()
    J['retained_autosome'] = rng_txt([100 * ret[('autosome', s)] for s in SAMPLES], 0)
    J['retained_X'] = rng_txt([100 * ret[('X', s)] for s in SAMPLES], 0)
    return J


def vs_grenedalf(full, say):
    ai = pd.read_csv(AIRI, sep='\t')
    ai = ai[(ai.analysis_class == 'autosome') & (ai.site_type == 'short_intron')].set_index('sample').Ne_primary
    out = {}
    for cfg in ('P98_RM', 'P99_noRM'):
        t = full[(full.cls == 'autosome') & (full.site_class == 'short_intron') & (full.config == cfg)]
        t = t.set_index('sample').Ne_tw
        v = [100 * (1 - t[s] / ai[s]) for s in SAMPLES]
        out[cfg] = rng_txt(v, 1)
        say(f'  my {cfg} thetaW Ne (short introns) vs Airi final grenedalf: ' + ', '.join(
            f'{s} {t[s] / 1e6:.3f} vs {ai[s] / 1e6:.3f}' for s in SAMPLES) + f'; mine lower by {out[cfg]}%')
    return out


def main():
    mode = sys.argv[1]
    s = '' if mode == 'check' else '_si40'
    log = open(f'{RES}/si40_numbers{"_check" if mode == "check" else ""}.log', 'w')

    def say(x):
        print(x, flush=True)
        log.write(x + '\n')

    say(f'mode {mode}; stats/div{s}, stats/dstd{s}; numpy {np.__version__}; pandas {pd.__version__}; seed {SEED}')
    full = ne_table(load('div', s), ['config', 'cls', 'sample', 'site_class'], 10000)
    dstd = ne_table(load('dstd', s), ['cls', 'sample', 'site_class'], 2000)
    say('full depth (P99_noRM) and depth-standardized (T = 30), autosomes:')
    J = numbers(full, dstd, say)
    J['vs_grenedalf'] = vs_grenedalf(full, say)
    if mode == 'check':
        # point estimates and site counts must equal the earlier summaries; intervals differ only by file order
        old = pd.read_csv(f'{RES}/L2_Ne.tsv', sep='\t').set_index(['config', 'cls', 'sample', 'site_class'])
        new = full.set_index(['config', 'cls', 'sample', 'site_class']).loc[old.index]
        assert (new.valid_sites == old.valid_sites).all() and np.allclose(new.Ne_tw, old.Ne_tw, rtol=1e-12)
        assert np.allclose(new.Ne_pi, old.Ne_pi, rtol=1e-12)
        say(f'  full-depth CI bounds, max relative difference to L2_Ne.tsv: '
            f'{np.max(np.abs(new[["Ne_tw_lo", "Ne_tw_hi"]].values / old[["Ne_tw_lo", "Ne_tw_hi"]].values - 1)):.4f}')
        old = pd.read_csv(f'{RES}/L2_depth_standardized_Ne.tsv', sep='\t').set_index(['cls', 'sample', 'site_class'])
        new = dstd.set_index(['cls', 'sample', 'site_class']).loc[old.index]
        assert (new.valid_sites == old.valid_sites).all() and np.allclose(new.Ne_tw / 1e6, old.Ne_tw, rtol=1e-12)
        J0 = json.load(open(f'{RES}/polarized_mk_excl/summary/additional_methods_numbers.json'))
        assert J['Ne_red_SI_all'] == J0['Ne_red_SI_all'] == '16–31' and J['Ne_red_FF_all'] == '27–40', J
        assert J['Ne_ci_overlap_any'] is False and J['retained_autosome'] == '91–99' and J['retained_X'] == '87–98', J
        say('CHECK PASSED: 30-65-bp outputs reproduce L2_Ne.tsv, L2_depth_standardized_Ne.tsv, 16–31%, 27–40%, '
            'no overlapping intervals, retained 91–99% and 87–98%')
    else:
        full.to_csv(f'{RES}/Ne_si40.tsv', sep='\t', index=False)
        dstd.to_csv(f'{RES}/depth_standardized_Ne_si40.tsv', sep='\t', index=False)
        json.dump(J, open(f'{RES}/si40_numbers.json', 'w'), ensure_ascii=False, indent=1)
    say(json.dumps(J, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
