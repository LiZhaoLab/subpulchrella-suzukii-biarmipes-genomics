"""Shared helpers for the depth analyses A3 and B1 (scripts/104, 105).

Per-site diversity in a fixed sample of reads: at each Step-0 site (scripts/97) the ancestral base
and the most frequent other base are kept (no frequency filter), N_SUB = 20 reads are drawn
without replacement, and pi_site = 2 j (n - j) / (n (n - 1)) with j = reads of the other base;
sites with j = 1 or n - 1 count as monomorphic (singletons removed against sequencing errors).
This statistic is the same for every pool whatever its depth; it is lower than full pi by a
factor that depends only on the spectrum shape. Pool-size correction: divide by (1 - 1/C).
Divergence from D. biarmipes per site: 1 - (reads of the D. biarmipes base) / depth.
Arms: D. subpulchrella chromosome of the gene (D. suzukii genes: chromosome of the
D. subpulchrella ortholog), so that D. suzukii chromosome 3 splits into 3L and 3R.
"""
import numpy as np
import pandas as pd

QC = '/ru-auth/local/home/lzhao/Data_scratch/zhao/suzukii_QC'
PROJ = '/ru-auth/local/home/lzhao/vscode_projects/suzukii'
RES = f'{PROJ}/results'
POOLS = ['Dsub_L5_7', 'JP-Kan', 'JP-Sap', 'JP-Sap2', 'JP-Tok']
DSUZ = POOLS[1:]
C_AUTO = {'Dsub_L5_7': 94, 'JP-Kan': 424, 'JP-Sap': 100, 'JP-Sap2': 302, 'JP-Tok': 100}
C_X = {'Dsub_L5_7': 94, 'JP-Kan': 241, 'JP-Sap': 54, 'JP-Sap2': 175, 'JP-Tok': 90}
ARM_DSUB = {'NC_050608.1': '4', 'NC_050609.1': '3R', 'NC_050610.1': '2L', 'NC_050611.1': '2R',
            'NC_050612.1': '3L', 'NC_050613.1': 'X', 'NW_023665577.1': '3R_scaffold'}
N_SUB, SEED = 20, 20261030


def site_pi_k(z, pre, rng, n_sub=N_SUB):
    """(pi_site, k_site, usable) arrays for the sites of one class prefix ('cds' or 'si')."""
    tot = z[f'{pre}_tot'].astype(np.int64)
    anc = z[f'{pre}_anc'].astype(np.int64)
    out = z[f'{pre}_out'].astype(np.int64)
    rows = np.arange(len(anc))
    depth = tot.sum(1)
    k_anc = tot[rows, anc]
    oth = tot.copy()
    oth[rows, anc] = -1
    k_oth = oth.max(1)
    usable = k_anc + k_oth >= n_sub
    j = np.zeros(len(anc), dtype=np.int64)
    j[usable] = rng.hypergeometric(k_oth[usable], k_anc[usable], n_sub)
    j = np.where((j == 1) | (j == n_sub - 1), 0, j)
    pi = 2 * j * (n_sub - j) / (n_sub * (n_sub - 1))
    k = 1 - tot[rows, out] / np.maximum(depth, 1)
    return pi, k, usable


def gene_tables():
    """Paired orthologs present in the D. subpulchrella table and in every D. suzukii table:
    DataFrame with dsub_tx, dsuz_tx, arm, and per pool the gene index in its table."""
    zs = {p: np.load(f'{QC}/site_table/{p}.npz') for p in POOLS}
    d = pd.DataFrame({'dsub_tx': zs['Dsub_L5_7']['genes'], 'dsuz_tx': zs['Dsub_L5_7']['gene_sister'],
                      'dsub_chrom': zs['Dsub_L5_7']['chroms'][zs['Dsub_L5_7']['gene_chrom']]})
    d['arm'] = d.dsub_chrom.map(ARM_DSUB)
    d['Dsub_L5_7'] = np.arange(len(d))
    for p in DSUZ:
        idx = pd.Series(np.arange(len(zs[p]['genes'])), index=zs[p]['genes'])
        d[p] = d.dsuz_tx.map(idx)
        sis = pd.Series(zs[p]['gene_sister'], index=zs[p]['genes'])
        d = d[d[p].notna() & (d.dsuz_tx.map(sis) == d.dsub_tx)]
    for p in DSUZ:
        d[p] = d[p].astype(int)
    return d.reset_index(drop=True), zs


def gene_sums(z, rng, cls_filter=None):
    """Per gene of one table: sums of pi and k and site counts for 0-fold, 4-fold and short-intron
    sites, and the mean position of the gene's coding sites (focal coordinates)."""
    G = len(z['genes'])
    out = {}
    pi, k, u = site_pi_k(z, 'cds', rng)
    g = z['cds_gene']
    for name, f in (('f0', 0), ('f4', 4)):
        m = u & (z['cds_fold'] == f)
        out[f'{name}_n'] = np.bincount(g[m], minlength=G)
        out[f'{name}_pi'] = np.bincount(g[m], weights=pi[m], minlength=G)
        out[f'{name}_k'] = np.bincount(g[m], weights=k[m], minlength=G)
        # disjoint halves of the four-fold sites (even / odd codon index), for A3
        if f == 4:
            for half, hm in (('even', z['cds_codon'] % 2 == 0), ('odd', z['cds_codon'] % 2 == 1)):
                mm = m & hm
                out[f'f4{half}_n'] = np.bincount(g[mm], minlength=G)
                out[f'f4{half}_pi'] = np.bincount(g[mm], weights=pi[mm], minlength=G)
    pi, k, u = site_pi_k(z, 'si', rng)
    gi = z['introns'][:, 0][z['si_intron']]
    out['si_n'] = np.bincount(gi[u], minlength=G)
    out['si_pi'] = np.bincount(gi[u], weights=pi[u], minlength=G)
    out['si_k'] = np.bincount(gi[u], weights=k[u], minlength=G)
    pos_sum = np.bincount(g, weights=z['cds_pos'].astype(float), minlength=G)
    out['pos'] = pos_sum / np.maximum(np.bincount(g, minlength=G), 1)
    out['chrom'] = z['chroms'][z['gene_chrom']]
    return pd.DataFrame(out)


def jc(k):
    return -0.75 * np.log(1 - 4 * k / 3)


def cds_density(gff, window=1_000_000):
    """{chrom: array of CDS base pairs (union over transcripts) per window}."""
    iv = {}
    with open(gff) as f:
        for line in f:
            t = line.split('\t')
            if len(t) > 8 and t[2] == 'CDS':
                iv.setdefault(t[0], []).append((int(t[3]), int(t[4])))
    dens = {}
    for c, lst in iv.items():
        lst.sort()
        merged = []
        for s, e in lst:
            if merged and s <= merged[-1][1] + 1:
                merged[-1][1] = max(merged[-1][1], e)
            else:
                merged.append([s, e])
        nwin = max(e for _, e in merged) // window + 1
        a = np.zeros(nwin)
        for s, e in merged:
            for w in range((s - 1) // window, (e - 1) // window + 1):
                lo, hi = max(s, w * window + 1), min(e, (w + 1) * window)
                a[w] += hi - lo + 1
        dens[c] = a
    return dens
