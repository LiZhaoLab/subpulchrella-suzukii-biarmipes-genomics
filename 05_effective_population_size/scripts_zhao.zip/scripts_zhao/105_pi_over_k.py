#!/usr/bin/env python3
"""Analysis B1 of the depth plan: neutral diversity relative to divergence from
D. biarmipes (pi/K), per chromosome arm and per 1-Mb window, in each species.

Question: is the large D. subpulchrella / D. suzukii diversity deficit on chromosome 3 a reduction
in D. subpulchrella or an excess in D. suzukii, and is it explained by variation in mutation rate?
Sites: four-fold and short-intron sites of orthologous genes present in all five Step-0 tables
(scripts/97); per-site pi in 20 reads without singletons, pool-size corrected, and divergence from
D. biarmipes (Jukes-Cantor) as in scripts/depth_common.py. K is measured on the same sites as pi,
so pi/K removes local variation in mutation rate (under the assumption that the rate is shared by
the polymorphism and the divergence).
Arm values: 1-Mb block bootstrap in each species' own coordinates (2,000 replicates; seed
20261030), species ratios from independent replicates.
Windows: 1-Mb windows in D. suzukii coordinates (JP-Kan table; orthologous D. subpulchrella genes
assigned to the window of their D. suzukii ortholog), windows with >= 3,000 four-fold sites.
Covariates: coding density (fraction of the window in CDS, D. suzukii RefSeq GFF) and distance
from the window centre to the nearer chromosome end (Mb). OLS with HC3 standard errors.
Outputs: results/B1_pi_over_k_arms.tsv, results/B1_pi_over_k_windows.tsv,
         results/B1_pi_over_k.log
"""
import time

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

import depth_common as dc

A = '/ru-auth/local/home/asato/scratch'
GFF_DSUZ = f'{A}/genome/Dsuz_IsoJpt1.0/GCF_043229965.1_CBGP_Dsuzu_IsoJpt1.0_genomic.gff'
GFF_DSUB = f'{A}/genome/Dsub_v1.1/GCF_014743375.2_RU_Dsub_v1.1_genomic.gff'
ARMS = ['2L', '2R', '3L', '3R', '3R_scaffold', 'X']
N_BOOT = int(__import__('os').environ.get('N_BOOT', 2000))


def arm_values(g, pool, rows):
    """g: per-gene sums for one pool, restricted to `rows`; returns dict of pi, K, pi/K."""
    s = g.loc[rows].sum(numeric_only=True)
    C = dc.C_X[pool] if rows.attrs.get('X') else dc.C_AUTO[pool]
    out = {}
    for c in ('f4', 'si'):
        pi = s[f'{c}_pi'] / s[f'{c}_n'] / (1 - 1 / C)
        k = dc.jc(s[f'{c}_k'] / s[f'{c}_n'])
        out.update({f'{c}_sites': int(s[f'{c}_n']), f'{c}_pi': pi, f'{c}_K': k, f'{c}_piK': pi / k})
    return out


def main():
    t0 = time.time()
    logf = open(f'{dc.RES}/B1_pi_over_k.log', 'w')

    def log(s):
        print(s, flush=True)
        logf.write(s + '\n')

    log(f'B1 pi/K; seed {dc.SEED}; n = {dc.N_SUB}; bootstraps {N_BOOT}; started {time.ctime()}')
    d, zs = dc.gene_tables()
    log(f'paired orthologous genes in all five tables: {len(d)}; by arm {d.arm.value_counts().to_dict()}')
    sums = {}
    for p in dc.POOLS:
        rng = np.random.default_rng(dc.SEED)
        g = dc.gene_sums(zs[p], rng)
        sums[p] = g.iloc[d[p].values].reset_index(drop=True)
    # blocks for the bootstrap: 1-Mb windows in each pool's own coordinates
    rng = np.random.default_rng(dc.SEED + 1)
    rows_out = []
    boot = {}
    for arm in ARMS:
        sel = (d.arm == arm).values
        for p in dc.POOLS:
            g = sums[p]
            idx = pd.Index(np.flatnonzero(sel))
            idx.attrs = {}
            r = pd.Series(idx)
            r.attrs = {'X': arm == 'X'}
            v = arm_values(g, p, r)
            blocks = (g.chrom.astype(str) + ':' + (g.pos // 1_000_000).astype(int).astype(str)).values[sel]
            ub = np.unique(blocks)
            bidx = [np.flatnonzero(sel)[blocks == b] for b in ub]
            bs = []
            for _ in range(N_BOOT):
                pick = rng.integers(0, len(ub), len(ub))
                rr = pd.Series(np.concatenate([bidx[i] for i in pick]))
                rr.attrs = {'X': arm == 'X'}
                bs.append(arm_values(g, p, rr))
            bs = pd.DataFrame(bs)
            boot[(arm, p)] = bs
            row = dict(arm=arm, pool=p, genes=int(sel.sum()), blocks=len(ub), **v)
            for c in ('f4_pi', 'f4_K', 'f4_piK', 'si_pi', 'si_K', 'si_piK'):
                row[f'{c}_lo'], row[f'{c}_hi'] = np.percentile(bs[c], [2.5, 97.5])
            rows_out.append(row)
    ar = pd.DataFrame(rows_out)
    # species ratios per arm
    rat = []
    for arm in ARMS:
        s = ar[(ar.arm == arm) & (ar.pool == 'Dsub_L5_7')].iloc[0]
        for p in dc.DSUZ:
            t = ar[(ar.arm == arm) & (ar.pool == p)].iloc[0]
            r = dict(arm=arm, pool=p)
            for c in ('f4_pi', 'f4_K', 'f4_piK', 'si_pi', 'si_K', 'si_piK'):
                r[f'ratio_{c}'] = s[c] / t[c]
                bb = boot[(arm, 'Dsub_L5_7')][c].values / boot[(arm, p)][c].values
                r[f'ratio_{c}_lo'], r[f'ratio_{c}_hi'] = np.percentile(bb, [2.5, 97.5])
            rat.append(r)
    rat = pd.DataFrame(rat)
    # each pool's arm pi/K relative to its own mean over the autosomal arms 2L, 2R, 3L, 3R
    for c in ('f4_piK', 'si_piK'):
        auto = ar[ar.arm.isin(['2L', '2R', '3L', '3R'])].groupby('pool')[c].mean()
        ar[f'{c}_rel_auto_mean'] = ar[c] / ar.pool.map(auto)
    ar.to_csv(f'{dc.RES}/B1_pi_over_k_arms.tsv', sep='\t', index=False)
    rat.to_csv(f'{dc.RES}/B1_pi_over_k_arm_ratios.tsv', sep='\t', index=False)
    log('\n== per arm, four-fold sites: pi, K (JC), pi/K [95% block bootstrap]; pi/K relative to the '
        "pool's autosomal mean")
    for r in ar.itertuples():
        log(f'{r.arm:12s} {r.pool:10s} genes {r.genes:5d} sites {r.f4_sites:8d} pi {r.f4_pi:.4f} K {r.f4_K:.4f} '
            f'pi/K {r.f4_piK:.4f} [{r.f4_piK_lo:.4f}-{r.f4_piK_hi:.4f}] rel {r.f4_piK_rel_auto_mean:.3f} | '
            f'short introns pi/K {r.si_piK:.4f} [{r.si_piK_lo:.4f}-{r.si_piK_hi:.4f}] rel {r.si_piK_rel_auto_mean:.3f}')
    log('\n== species ratios D. subpulchrella / D. suzukii pool, per arm')
    for r in rat.itertuples():
        log(f'{r.arm:12s} vs {r.pool:8s} four-fold: pi {r.ratio_f4_pi:.3f} [{r.ratio_f4_pi_lo:.3f}-'
            f'{r.ratio_f4_pi_hi:.3f}] K {r.ratio_f4_K:.3f} [{r.ratio_f4_K_lo:.3f}-{r.ratio_f4_K_hi:.3f}] '
            f'pi/K {r.ratio_f4_piK:.3f} [{r.ratio_f4_piK_lo:.3f}-{r.ratio_f4_piK_hi:.3f}] | introns pi/K '
            f'{r.ratio_si_piK:.3f} [{r.ratio_si_piK_lo:.3f}-{r.ratio_si_piK_hi:.3f}]')
    # windows in D. suzukii coordinates
    kan = sums['JP-Kan']
    win = (kan.chrom.astype(str) + ':' + (kan.pos // 1_000_000).astype(int).astype(str)).values
    dens = dc.cds_density(GFF_DSUZ)
    lengths = {}
    sz = np.load(f'{dc.QC}/sweeps/JP-Kan/summary.npz')
    for k in sz.files:
        if k.endswith('|length'):
            lengths[k.split('|')[0]] = int(sz[k][0])
    wrows = []
    for w in np.unique(win):
        m = win == w
        chrom, wi = w.split(':')
        wi = int(wi)
        if chrom not in lengths or d.arm[m].mode().iloc[0] in ('4',):
            continue
        r = dict(window=w, chrom=chrom, start_mb=wi, genes=int(m.sum()), arm=d.arm[m].mode().iloc[0],
                 cds_density=dens[chrom][wi] / 1e6 if wi < len(dens.get(chrom, [])) else np.nan,
                 dist_end_mb=min(wi + 0.5, lengths[chrom] / 1e6 - wi - 0.5))
        for p in dc.POOLS:
            s = sums[p][m].sum(numeric_only=True)
            cpool = dc.C_X[p] if r['arm'] == 'X' else dc.C_AUTO[p]
            for c in ('f4', 'si'):
                r[f'{p}_{c}_n'] = int(s[f'{c}_n'])
                r[f'{p}_{c}_pi'] = s[f'{c}_pi'] / max(s[f'{c}_n'], 1) / (1 - 1 / cpool)
                r[f'{p}_{c}_K'] = dc.jc(s[f'{c}_k'] / max(s[f'{c}_n'], 1))
        wrows.append(r)
    wd = pd.DataFrame(wrows)
    wd = wd[(wd['JP-Kan_f4_n'] >= 3000) & (wd['Dsub_L5_7_f4_n'] >= 3000)]
    wd.to_csv(f'{dc.RES}/B1_pi_over_k_windows.tsv', sep='\t', index=False)
    log(f'\n== 1-Mb windows (D. suzukii coordinates), >= 3,000 four-fold sites in both species: {len(wd)}')
    au = wd[wd.arm != 'X'].copy()
    for p in dc.POOLS:
        au[f'lpk_{p}'] = np.log(au[f'{p}_f4_pi'] / au[f'{p}_f4_K'])
    for p in dc.POOLS:
        f = smf.ols(f'Q("lpk_{p}") ~ cds_density + dist_end_mb', data=au).fit(cov_type='HC3')
        log(f'autosomal windows, log(pi4/K4) of {p}: cds_density slope {f.params["cds_density"]:.3f} '
            f'(SE {f.bse["cds_density"]:.3f}, P {f.pvalues["cds_density"]:.2g}); dist_end slope '
            f'{f.params["dist_end_mb"]:.4f} per Mb (SE {f.bse["dist_end_mb"]:.4f}, P {f.pvalues["dist_end_mb"]:.2g}); '
            f'R2 {f.rsquared:.3f}; n {int(f.nobs)}')
    for p in dc.DSUZ:
        au['lr'] = au['lpk_Dsub_L5_7'] - au[f'lpk_{p}']
        f = smf.ols('lr ~ cds_density + dist_end_mb', data=au).fit(cov_type='HC3')
        log(f'autosomal windows, log ratio Dsub/{p} of pi4/K4: cds_density slope {f.params["cds_density"]:.3f} '
            f'(SE {f.bse["cds_density"]:.3f}, P {f.pvalues["cds_density"]:.2g}); dist_end slope '
            f'{f.params["dist_end_mb"]:.4f} (SE {f.bse["dist_end_mb"]:.4f}, P {f.pvalues["dist_end_mb"]:.2g}); '
            f'R2 {f.rsquared:.3f}')
        f2 = smf.ols('lr ~ C(arm)', data=au).fit(cov_type='HC3')
        log(f'   arm effect on the log ratio (reference {sorted(au.arm.unique())[0]}): '
            + ', '.join(f'{k} {v:.3f} (P {f2.pvalues[k]:.2g})' for k, v in f2.params.items() if k != 'Intercept'))
    # D. subpulchrella in its own coordinates (scaffold NW_023665577.1 excluded: position unknown)
    sub = sums['Dsub_L5_7']
    own = pd.DataFrame({'chrom': sub.chrom.astype(str), 'w': (sub.pos // 1_000_000).astype(int),
                        'arm': d.arm})
    dens_s = dc.cds_density(GFF_DSUB)
    ls = {}
    zz = np.load(f'{dc.QC}/sweeps/Dsub_L5_7/summary.npz')
    for k in zz.files:
        if k.endswith('|length'):
            ls[k.split('|')[0]] = int(zz[k][0])
    orows = []
    for (chrom, w), grp in own.groupby(['chrom', 'w']):
        arm = grp.arm.mode().iloc[0]
        if arm in ('4', 'X', '3R_scaffold'):
            continue
        s = sub.loc[grp.index].sum(numeric_only=True)
        if s['f4_n'] < 3000:
            continue
        orows.append(dict(chrom=chrom, start_mb=w, arm=arm, cds_density=dens_s[chrom][w] / 1e6,
                          dist_end_mb=min(w + 0.5, ls[chrom] / 1e6 - w - 0.5),
                          lpk=np.log(s['f4_pi'] / s['f4_n'] / dc.jc(s['f4_k'] / s['f4_n']))))
    od = pd.DataFrame(orows)
    f = smf.ols('lpk ~ cds_density + dist_end_mb', data=od).fit(cov_type='HC3')
    log(f'D. subpulchrella own coordinates, autosomal 1-Mb windows (n {len(od)}), log(pi4/K4): cds_density '
        f'slope {f.params["cds_density"]:.3f} (SE {f.bse["cds_density"]:.3f}, P {f.pvalues["cds_density"]:.2g}); '
        f'dist_end slope {f.params["dist_end_mb"]:.4f} per Mb (SE {f.bse["dist_end_mb"]:.4f}, '
        f'P {f.pvalues["dist_end_mb"]:.2g}); R2 {f.rsquared:.3f}')
    od.to_csv(f'{dc.RES}/B1_pi_over_k_windows_dsub_own.tsv', sep='\t', index=False)
    log(f'finished {time.ctime()} ({time.time() - t0:.0f} s)')


if __name__ == '__main__':
    main()
