#!/usr/bin/env python3
"""Neutral-site diversity per orthologous gene, and pool allele-frequency spectra along the arms
(analysis 4.1 of Project_Status.md: where along each arm is the D. subpulchrella
diversity deficit?).

Genes: D. subpulchrella - D. suzukii reciprocal best hits (Airi's orth_longest table) whose CDS
models (RefSeq GFF, one chromosome and strand) lie on the major chromosomes of each species.
Per sample and gene, from my per-site pool allele counts (01_pileup_counts.py) and the estimator
of 32_chunk_stats.py (Kofler et al. 2011; minimum allele count 2; pool sizes as in script 32),
in the Ne configuration P99_noRM (depth >= max(10, P5) and <= P99, outside indel masks, no
RepeatMasker mask):
  ff_n, ff_pi : valid four-fold sites in the gene's CDS and the sum of per-site pi;
  si_n, si_pi : valid short-intron sites between the first and last CDS base, and sum of pi.
Allele-frequency spectrum: per 500-kb window, folded minor-allele frequency of valid SNPs at all
sites (P99_noRM), in 25 bins of width 0.02; minor frequency = second allele count / M, where M
counts alleles with >= 2 reads (as in script 32).
Outputs: results/genes_neutral_pi.tsv, results/window_sfs.tsv.gz
Usage: 76_neutral_diversity_by_gene.py [SAMPLE ...]   (default: all five pools)
"""
import glob
import importlib.util
import sys

import numpy as np
import pandas as pd

PROJ = '/ru-auth/local/home/lzhao/vscode_projects/suzukii'
QC = '/ru-auth/local/home/lzhao/Data_scratch/zhao/suzukii_QC'
A = '/ru-auth/local/home/asato/scratch'
MK = f'{A}/MKtest/reanalysis_longest_fix_20260817'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


cs = load('cs', f'{PROJ}/scripts/32_chunk_stats.py')
pm = load('pm', f'{PROJ}/scripts/60_polarized_mk.py')
SAMPLES = sys.argv[1:] or ['Dsub_L5_7', 'JP-Kan', 'JP-Sap', 'JP-Sap2', 'JP-Tok']
SFS_WIN, SFS_BINS = 500_000, np.linspace(0, 0.5, 26)

regions = f'{A}/population_polymorphism/reanalysis_20260821/config/regions'
major = {sp: {l.split()[0] for cls in ('autosome', 'X') for l in open(f'{regions}/{sp}.{cls}.bed')}
         for sp in ('Dsub', 'Dsuz')}
models = {sp: pm.cds_models(pm.GFF[sp], major[sp]) for sp in ('Dsub', 'Dsuz')}
o = pd.read_csv(f'{MK}/orth_longest/Dsuz_Dsub.direct.RBH.longest.mRNA.tsv', sep='\t', header=None)
pairs = pd.DataFrame({'dsub_gene': o[0].map(pm.strip), 'dsuz_gene': o[1].map(pm.strip)})
pairs = pairs[pairs.dsub_gene.isin(models['Dsub']) & pairs.dsuz_gene.isin(models['Dsuz'])]
assert pairs.dsub_gene.is_unique and pairs.dsuz_gene.is_unique
for sp, col in (('Dsub', 'dsub'), ('Dsuz', 'dsuz')):
    m = models[sp]
    pairs[f'{col}_chrom'] = pairs[f'{col}_gene'].map(lambda t: m[t][0])
    pairs[f'{col}_start'] = pairs[f'{col}_gene'].map(lambda t: int(m[t][1].min()))
    pairs[f'{col}_end'] = pairs[f'{col}_gene'].map(lambda t: int(m[t][1].max()))
print(f'gene pairs on major chromosomes: {len(pairs)}', flush=True)

out_genes = pairs.copy()
sfs_rows = []
for sample in SAMPLES:
    sp = 'Dsub' if sample.startswith('Dsub') else 'Dsuz'
    col = sp.lower()
    gl = pairs[f'{col}_gene'].tolist()
    acc = {k: np.zeros(len(gl)) for k in ('ff_n', 'ff_pi', 'si_n', 'si_pi')}
    ms = np.load(f'{QC}/masks_sites/{sp}.npz')
    for chrom in sorted(major[sp]):
        files = sorted(glob.glob(f'{QC}/counts/{sample}/{chrom}_*.npz'), key=lambda f: int(f.split('_')[-2]))
        if not files:
            continue
        cls = 'X' if chrom in cs.XCHROM else 'autosome'
        n = cs.POOL[sample][1 if cls == 'X' else 0]
        dmin, dmax = cs.thresholds(sample, cls)
        cw, cp = cs.corrections(n, dmax['p99'])
        ff, si = ms[f'{chrom}|ff'], ms[f'{chrom}|si']
        L = len(ff)
        g_ff = np.full(L + 1, -1, dtype=np.int32)          # index = position; gene of each CDS site
        g_sp = np.full(L + 1, -1, dtype=np.int32)          # gene span (first to last CDS base)
        for i, t in enumerate(gl):
            c, pos, _ = models[sp][t]
            if c != chrom:
                continue
            g_sp[pos.min():pos.max() + 1] = np.where(g_sp[pos.min():pos.max() + 1] < 0, i,
                                                     g_sp[pos.min():pos.max() + 1])
            g_ff[pos] = np.where(g_ff[pos] < 0, i, g_ff[pos])
        for f in files:
            start, end = int(f.split('_')[-2]), int(f.split('_')[-1].split('.')[0])
            c4, indel = cs.load_chunk(sample, chrom, start, end)
            depth = c4.sum(axis=1)
            snp, pi, _ = cs.site_stats(c4, n, cw, cp)
            valid = (depth >= dmin) & (depth <= dmax['p99']) & ~indel
            sl = slice(start, end + 1)                     # mask index = position (as in script 32)
            for key, mask, gidx in (('ff', ff[sl], g_ff[sl]), ('si', si[sl], g_sp[sl])):
                v = valid & mask & (gidx >= 0)
                acc[f'{key}_n'] += np.bincount(gidx[v], minlength=len(gl))
                acc[f'{key}_pi'] += np.bincount(gidx[v], weights=pi[v], minlength=len(gl))
            # folded minor-allele frequency spectrum of valid SNPs, per 500-kb window
            cz = np.where(c4 >= cs.B, c4, 0)
            M = cz.sum(axis=1)
            v = valid & snp
            srt = np.sort(cz[v], axis=1)
            maf = srt[:, -2] / M[v]
            pos = np.arange(start, end + 1)
            w0 = (start - 1) // SFS_WIN
            nw = (end - 1) // SFS_WIN - w0 + 1
            w = (pos[v] - 1) // SFS_WIN - w0
            b = np.clip(np.digitize(maf, SFS_BINS) - 1, 0, len(SFS_BINS) - 2)
            h = np.zeros((nw, len(SFS_BINS) - 1), dtype=np.int64)
            np.add.at(h, (w, b), 1)
            nval = np.bincount((pos[valid] - 1) // SFS_WIN - w0, minlength=nw)
            for k in range(nw):
                sfs_rows.append([sample, chrom, int((w0 + k) * SFS_WIN + 1), int(nval[k])] + h[k].tolist())
        print(f'{sample} {chrom} done', flush=True)
    for k, v in acc.items():
        out_genes[f'{sample}|{k}'] = v

out_genes.to_csv(f'{PROJ}/results/genes_neutral_pi.tsv', sep='\t', index=False)
cols = ['sample', 'chrom', 'win_start', 'valid_sites'] + [f'maf_{SFS_BINS[i]:.2f}' for i in range(len(SFS_BINS) - 1)]
sfs = pd.DataFrame(sfs_rows, columns=cols)
# windows split across count chunks are summed
sfs = sfs.groupby(['sample', 'chrom', 'win_start'], as_index=False).sum()
sfs.to_csv(f'{PROJ}/results/window_sfs.tsv.gz', sep='\t', index=False)
print('written', len(out_genes), 'gene pairs;', len(sfs), 'SFS windows')
