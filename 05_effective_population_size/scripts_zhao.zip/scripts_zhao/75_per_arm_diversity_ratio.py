#!/usr/bin/env python3
"""Per-arm D. subpulchrella / D. suzukii neutral-site diversity ratio, with 1-Mb block bootstrap
(2,000 replicates, seed 20261023; blocks resampled within each arm and sample independently).
Config P99_noRM (the Ne configuration). D. suzukii chromosome 3 is not split into 3L and 3R.
Also: across arms, correlation of the Ds excess on the D. subpulchrella lineage (polarized MK,
JP-Kan) with the Ps deficit (Pearson and Spearman; 7 arms, so descriptive only).
"""
import os
import glob

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

D = '/ru-auth/local/home/lzhao/Data_scratch/zhao/suzukii_QC/stats/div'
VARIANT = os.environ.get('PMK_VARIANT', '')   # 'excl' = 60_polarized_mk.py EXCLUDE_SHARED=1
PMK = '/ru-auth/local/home/lzhao/vscode_projects/suzukii/results/polarized_mk' + (f'_{VARIANT}' if VARIANT else '')
A = '/ru-auth/local/home/asato/scratch/MKtest/reanalysis_longest_fix_20260817'
ARM = {'NC_050608.1': '4', 'NC_050609.1': '3R', 'NC_050610.1': '2L', 'NC_050611.1': '2R',
       'NC_050612.1': '3L', 'NC_050613.1': 'X', 'NW_023665577.1': '3R_scaffold',
       'NC_092080.1': '2L', 'NC_092081.1': '2R', 'NC_092082.1': '3', 'NC_092083.1': '4', 'NC_092084.1': 'X'}
PAIR = [('2L', '2L'), ('2R', '2R'), ('3L', '3'), ('3R', '3'), ('3R_scaffold', '3'), ('X', 'X')]
POPS = ('JP-Kan', 'JP-Sap', 'JP-Sap2', 'JP-Tok')
rng = np.random.default_rng(20261023)

b = pd.concat([pd.read_csv(f, sep='\t') for f in glob.glob(f'{D}/*blocks.tsv.gz')])
b = b[b.config == 'P99_noRM'].assign(arm=lambda x: x.chrom.map(ARM))
assert b.arm.notna().all()


def boot(x, B=2000):
    n, p = x.n_valid.to_numpy(), x.sum_pi.to_numpy()
    i = rng.integers(0, len(x), (B, len(x)))
    return p[i].sum(1) / n[i].sum(1), p.sum() / n.sum()


rows = []
for sc in ('fourfold', 'short_intron'):
    for a, za in PAIR:
        s = b[(b.site_class == sc) & (b['sample'] == 'Dsub_L5_7') & (b.arm == a)]
        bs, ps = boot(s)
        for pop in POPS:
            z = b[(b.site_class == sc) & (b['sample'] == pop) & (b.arm == za)]
            bz, pz = boot(z)
            r = bs / bz
            rows.append(dict(site_class=sc, arm=a, pop=pop, blocks_sub=len(s), ratio=ps / pz,
                             lo=np.percentile(r, 2.5), hi=np.percentile(r, 97.5)))
r = pd.DataFrame(rows)
summ = r.groupby(['site_class', 'arm'], sort=False).agg(
    blocks=('blocks_sub', 'first'), ratio_min=('ratio', 'min'), ratio_max=('ratio', 'max'),
    lo_min=('lo', 'min'), hi_max=('hi', 'max'))
print('== Dsub/Dsuz pi ratio per arm (range over 4 D. suzukii pools; CI = widest 95% bootstrap bounds)')
print(summ.round(3).to_string())

# across arms: Ds excess vs Ps deficit (paired RBH genes, JP-Kan)
o = pd.read_csv(f'{A}/orth_longest/Dsuz_Dsub.direct.RBH.longest.mRNA.tsv', sep='\t', header=None)
s2z = dict(zip(o[0].str.replace('rna-', ''), o[1].str.replace('rna-', '')))
sub = pd.read_csv(f'{PMK}/Dsub_L5_7.genes.tsv', sep='\t', index_col='gene')
print('\n== across arms: Ds ratio (Dsub/Dsuz lineage) vs Ps ratio (Dsub/Dsuz pool), per callable codon')
for pop in POPS:
    suz = pd.read_csv(f'{PMK}/{pop}.genes.tsv', sep='\t', index_col='gene')
    pr = sub[sub.index.map(lambda g: s2z.get(g) in suz.index)].copy()
    z = suz.loc[pr.index.map(s2z)]
    for c in ('callable', 'Ds_focal', 'Ps'):
        pr[c + '_z'] = z[c].to_numpy()
    pr = pr[(pr.callable > 0) & (pr.callable_z > 0)].assign(arm=lambda x: x.chrom.map(ARM))
    pr = pr[pr.arm != '4']
    g = pr.groupby('arm')[['callable', 'Ds_focal', 'Ps', 'callable_z', 'Ds_focal_z', 'Ps_z']].sum()
    dsr = (g.Ds_focal / g.callable) / (g.Ds_focal_z / g.callable_z)
    psr = (g.Ps / g.callable) / (g.Ps_z / g.callable_z)
    print(f'{pop}: ' + '; '.join(f'{a} Ds {dsr[a]:.2f} Ps {psr[a]:.2f}' for a in g.index) +
          f' | Pearson r {pearsonr(psr, dsr)[0]:.2f}, Spearman rho {spearmanr(psr, dsr)[0]:.2f} (n = {len(g)} arms)')
