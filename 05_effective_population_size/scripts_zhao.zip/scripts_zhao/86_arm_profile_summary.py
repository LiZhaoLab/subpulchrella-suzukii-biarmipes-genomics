#!/usr/bin/env python3
"""Analysis 4.1: where along the chromosomes is the D. subpulchrella diversity deficit?
Input: results/genes_neutral_pi.tsv and results/window_sfs.tsv.gz (script 76).

A. Four-fold pi ratio D. subpulchrella / mean of the four D. suzukii pools, per D. subpulchrella arm,
   all orthologous gene pairs and after excluding E = 2, 3, 5 Mb at the ends of each chromosome in
   both assemblies and around the D. suzukii chromosome-3 gene desert (the largest gap between
   consecutive orthologous genes on NC_092082.1); also short-intron sites.
B. 1-Mb windows in D. suzukii coordinates (gene midpoints; windows with >= 3,000 valid four-fold
   sites in each species): pi of each species and the ratio; Spearman correlation of the ratio with
   distance from the chromosome-3 gene desert on each arm.
C. Folded allele-frequency spectrum of the D. subpulchrella pool: fraction of SNPs with minor-allele
   frequency >= 0.30 among SNPs >= 0.05, in low-ratio and other regions (an inversion polymorphism at
   frequency f would add SNPs near f; reduced diversity from linked selection shifts the spectrum
   toward rare variants).
Figure: results/arm_profile.png (palette validated with the dataviz validator: blue
#2a78d6 / orange #eb6834, all checks pass on the light surface).
"""
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJ = '/ru-auth/local/home/lzhao/vscode_projects/suzukii'
R = f'{PROJ}/results'
POPS = ['JP-Kan', 'JP-Sap', 'JP-Sap2', 'JP-Tok']
ARM = {'NC_050609.1': '3R', 'NC_050610.1': '2L', 'NC_050611.1': '2R', 'NC_050612.1': '3L',
       'NC_050613.1': 'X', 'NW_023665577.1': '3R_scaffold'}
ZCH = {'NC_092080.1': '2L', 'NC_092081.1': '2R', 'NC_092082.1': '3', 'NC_092084.1': 'X'}
FAI = ['/ru-auth/local/home/asato/scratch/genome/Dsub_v1.1/GCF_014743375.2_RU_Dsub_v1.1_genomic.fna.fai',
       '/ru-auth/local/home/asato/scratch/genome/Dsuz_IsoJpt1.0/GCF_043229965.1_CBGP_Dsuzu_IsoJpt1.0_genomic.fna.fai']
clen = {l.split()[0]: int(l.split()[1]) for f in FAI for l in open(f)}

g = pd.read_csv(f'{R}/genes_neutral_pi.tsv', sep='\t')
g['arm'] = g.dsub_chrom.map(ARM)
g = g[g.arm.notna()].copy()
g['zmid'] = (g.dsuz_start + g.dsuz_end) / 2
g['smid'] = (g.dsub_start + g.dsub_end) / 2


def ratio(x, k='ff'):
    s = x[f'Dsub_L5_7|{k}_pi'].sum() / x[f'Dsub_L5_7|{k}_n'].sum()
    z = np.mean([x[f'{p}|{k}_pi'].sum() / x[f'{p}|{k}_n'].sum() for p in POPS])
    return s / z


z3 = np.sort(g.zmid[g.dsuz_chrom == 'NC_092082.1'].values)
i = np.argmax(np.diff(z3))
c0, c1 = z3[i], z3[i + 1]
print(f'D. suzukii chromosome-3 gene desert (largest ortholog gap): {c0 / 1e6:.1f}-{c1 / 1e6:.1f} Mb')

# ---------------------------------------------------------------- A
rows = []
for E in (0, 2, 3, 5):
    e = E * 1e6
    zl, sl = g.dsuz_chrom.map(clen), g.dsub_chrom.map(clen)
    near_gap = (g.dsuz_chrom == 'NC_092082.1') & (g.zmid > c0 - e) & (g.zmid < c1 + e)
    zend = (g.zmid <= e) | (g.zmid >= zl - e)
    send = ((g.smid <= e) | (g.smid >= sl - e)) & (g.arm != '3R_scaffold')   # scaffold ends are not chromosome ends
    keep = ~(zend | send | near_gap) if E else pd.Series(True, index=g.index)
    for arm, x in list(g[keep].groupby('arm')) + [('all', g[keep])]:
        rows.append(dict(excluded_Mb=E, arm=arm, genes=len(x), fourfold_ratio=round(ratio(x), 3),
                         short_intron_ratio=round(ratio(x, 'si'), 3)))
A = pd.DataFrame(rows)
A.to_csv(f'{R}/arm_interior_ratios.tsv', sep='\t', index=False)
print(A.pivot(index='arm', columns='excluded_Mb', values='fourfold_ratio').to_string())

# ---------------------------------------------------------------- B
g['zchr'] = g.dsuz_chrom.map(ZCH)
g['bin'] = (g.zmid // 1e6).astype(int)
wrows = []
for (zc, b), x in g[g.zchr.notna()].groupby(['zchr', 'bin']):
    ns = x['Dsub_L5_7|ff_n'].sum()
    nz = min(x[f'{p}|ff_n'].sum() for p in POPS)
    if ns < 3000 or nz < 3000:
        continue
    ps = x['Dsub_L5_7|ff_pi'].sum() / ns
    pz = np.mean([x[f'{p}|ff_pi'].sum() / x[f'{p}|ff_n'].sum() for p in POPS])
    wrows.append(dict(dsuz_chrom=zc, bin_Mb=b, genes=len(x), dsub_arm=x.arm.mode().iloc[0],
                      ff_sites_dsub=int(ns), pi_dsub=ps, pi_dsuz=pz, ratio=ps / pz))
W = pd.DataFrame(wrows)
W.to_csv(f'{R}/arm_windows.tsv', sep='\t', index=False)
print(f'\n1-Mb windows: {len(W)}; ratio median {W.ratio.median():.2f}, 10-90% '
      f'{W.ratio.quantile(0.1):.2f}-{W.ratio.quantile(0.9):.2f}; windows with ratio > 1: {(W.ratio > 1).sum()}; < 0.5: {(W.ratio < 0.5).sum()}')
w3 = W[W.dsuz_chrom == '3'].copy()
w3['dist'] = np.where((w3.bin_Mb + 0.5) * 1e6 < c0, c0 - (w3.bin_Mb + 0.5) * 1e6, (w3.bin_Mb + 0.5) * 1e6 - c1) / 1e6
for side, x in (('3L side', w3[(w3.bin_Mb + 0.5) * 1e6 < c0]), ('3R side', w3[(w3.bin_Mb + 0.5) * 1e6 > c1])):
    rho, p = spearmanr(x.dist, x.ratio)
    print(f'{side}: {len(x)} windows; Spearman rho(ratio, distance from gene desert) = {rho:.2f} (P = {p:.2g})')

# ---------------------------------------------------------------- C
s = pd.read_csv(f'{R}/window_sfs.tsv.gz', sep='\t')
cols = [c for c in s.columns if c.startswith('maf_')]
lo = np.array([float(c[4:]) for c in cols])
s = s[(s['sample'] == 'Dsub_L5_7') & (s.valid_sites > 100000)].copy()
s['arm'] = s.chrom.map(ARM)
s['mb'] = (s.win_start // 1e6).astype(int)
ge05 = s[[c for c, l in zip(cols, lo) if l >= 0.05]].sum(1)
s['f_int'] = s[[c for c, l in zip(cols, lo) if l >= 0.30]].sum(1) / ge05
regions = [('3R', 0, 8, 'low ratio (0.40-0.60)'), ('3R_scaffold', 0, 6, 'low ratio (0.22-0.53)'),
           ('3L', 3, 9, 'low ratio (0.42-0.72)'), ('3R', 11, 18, 'ratio 0.60-0.80'),
           ('2R', 0, 15, 'ratio 0.65-0.93'), ('2L', 16, 24, 'ratio 0.68-0.88')]
crows = []
for arm, a, b, lab in regions:
    x = s[(s.arm == arm) & (s.mb >= a) & (s.mb <= b)]
    crows.append(dict(region=f'{arm} {a}-{b + 1} Mb', label=lab, windows_500kb=len(x),
                      frac_maf_ge_0p30=round(x.f_int.median(), 3)))
C = pd.DataFrame(crows)
C.to_csv(f'{R}/arm_sfs_regions.tsv', sep='\t', index=False)
print('\n', C.to_string(index=False))
print(f'all D. subpulchrella 500-kb windows: median {s.f_int.median():.3f}, 5-95% {s.f_int.quantile(0.05):.3f}-{s.f_int.quantile(0.95):.3f}')

# ---------------------------------------------------------------- figure
INK, INK2, GRID, SURF = '#0b0b0b', '#52514e', '#e4e3df', '#fcfcfb'
BLUE, ORANGE = '#2a78d6', '#eb6834'
plt.rcParams.update({'font.size': 9, 'axes.edgecolor': INK2, 'axes.labelcolor': INK, 'xtick.color': INK2,
                     'ytick.color': INK2, 'text.color': INK, 'figure.facecolor': SURF, 'axes.facecolor': SURF})
order = ['2L', '2R', '3', 'X']
widths = [W[W.dsuz_chrom == c].bin_Mb.max() + 1 for c in order]
fig, ax = plt.subplots(2, 4, figsize=(13, 5.6), sharey='row', gridspec_kw=dict(width_ratios=widths, hspace=0.12, wspace=0.06))
for j, c in enumerate(order):
    x = W[W.dsuz_chrom == c].sort_values('bin_Mb')
    gap = x.bin_Mb.diff().fillna(1) > 2                 # break lines across missing windows
    if gap.any():
        brk = x[gap].assign(bin_Mb=lambda d: d.bin_Mb - 1, pi_dsub=np.nan, pi_dsuz=np.nan, ratio=np.nan)
        x = pd.concat([x, brk]).sort_values('bin_Mb')
    xm = x.bin_Mb + 0.5
    a0, a1 = ax[0, j], ax[1, j]
    a0.plot(xm, x.pi_dsub, color=BLUE, lw=2, marker='o', ms=3, label='D. subpulchrella')
    a0.plot(xm, x.pi_dsuz, color=ORANGE, lw=2, marker='o', ms=3, label='D. suzukii (mean of 4 pools)')
    a1.plot(xm, x.ratio, color=INK2, lw=2, marker='o', ms=3)
    a1.axhline(1, color=INK2, lw=1)
    a1.axhline(ratio(g), color=INK2, lw=1, ls='--')
    a1.set_yscale('log', base=2)
    a1.set_yticks([0.25, 0.5, 1, 2])
    a1.set_yticklabels(['0.25', '0.5', '1', '2'])
    for a in (a0, a1):
        a.grid(axis='y', color=GRID, lw=0.8)
        a.set_axisbelow(True)
        for sp_ in ('top', 'right'):
            a.spines[sp_].set_visible(False)
        if c == '3':
            a.axvspan(c0 / 1e6, c1 / 1e6, color=GRID, lw=0)
    a0.set_title(c if c != '3' else '3  (left of the gene desert: D. subpulchrella 3L genes; right: 3R and NW_023665577.1 genes)',
                 fontsize=9, color=INK)
    a0.set_xticklabels([])
    if c == '3':
        a0.text((c0 + c1) / 2e6, 0.072, 'gene\ndesert', ha='center', va='top', fontsize=8, color=INK2)
ax[0, 0].set_ylabel('four-fold π')
ax[1, 0].set_ylabel('ratio D. subpulchrella /\nD. suzukii (log scale)')
ax[1, 0].set_ylim(0.2, 4)
ax[0, 0].set_ylim(0, 0.08)
ax[0, 3].legend(frameon=False, loc='upper right', fontsize=8)
ax[1, 2].text(27, ratio(g) * 0.93, f'dashed line: all genes, {ratio(g):.2f}', ha='left', va='top', fontsize=8, color=INK2)
fig.text(0.5, 0.02, 'D. suzukii chromosome (panel title) and position in the D. suzukii assembly (Mb)', ha='center', color=INK)
fig.suptitle('Neutral diversity of orthologous genes in 1-Mb windows (four-fold sites, Ne filter configuration)',
             fontsize=10, color=INK, x=0.01, ha='left')
fig.savefig(f'{R}/arm_profile.png', dpi=160, bbox_inches='tight')
print('figure written')
